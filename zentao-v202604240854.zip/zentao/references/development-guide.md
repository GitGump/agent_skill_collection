# Zentao CLI 开发指南

本文档记录开发 Zentao CLI 的经验，供二次开发参考。

## 开发背景

禅道提供 REST API v1，但部分接口存在 BUG 或功能不完整。需要通过浏览器工具探测传统 HTML 表单端点，实现完整功能。

## 技术方案选择

### 方案对比

| 方案 | 优点 | 缺点 | 适用场景 |
|------|------|------|---------|
| REST API | 官方支持、JSON 格式、文档完善 | 部分接口有 BUG | 查询、基础 CRUD |
| 传统表单 | 功能完整、与 Web 一致 | 非官方、依赖 HTML 结构 | 状态变更、复杂操作 |

### 混合方案

```
查询操作 → REST API
创建/更新 → 优先 REST，失败则表单
状态变更 → 传统表单
```

---

## 浏览器探测流程

### 什么时候需要探测

1. REST API 返回 500 错误
2. REST API 返回的数据结构异常
3. REST API 没有所需操作（如任务状态变更）
4. 官方文档没有记录的接口

### 工具选择

| 工具 | 场景 | 优势 |
|------|------|------|
| `opencli-browser` | 快速探测、脚本化 | 可复用、可编程 |
| `playwright_*` | 复杂交互、截图 | 可视化调试 |
| `chrome-devtools_*` | 实时调试、Network 面板 | 功能完整 |

### 探测步骤

#### 1. 打开禅道并登录

```bash
# 使用 opencli 打开页面
opencli navigate "http://10.240.1.200"

# 或使用 playwright
playwright_browser_navigate --url "http://10.240.1.200"
```

#### 2. 手动执行目标操作

在浏览器中手动执行一次目标操作（如创建任务），同时观察 Network 面板。

#### 3. 捕获请求

```bash
# 列出网络请求
playwright_browser_network_requests --static false --requestBody true --requestHeaders true

# 或使用 chrome-devtools
chrome-devtools_list_network_requests --resourceTypes '["xhr", "fetch"]'
```

#### 4. 分析请求格式

关注：
- **URL**: `/task-create-1-340.html?T=json`
- **Method**: POST
- **Content-Type**: `application/x-www-form-urlencoded`
- **Request Body**: `name=任务名&type=devel&estHour=8`
- **Response**: JSON 或 HTML

#### 5. 提取关键参数

```bash
# 获取具体请求详情
chrome-devtools_get_network_request --reqid 123
```

---

## 传统表单方式实现

### 发现表单端点

以任务创建为例：

1. 打开任务创建页面：`/task-create-{project}-{execution}.html`
2. 查看表单字段（浏览器开发者工具 → Elements）
3. 提取表单字段名：`name`, `type`, `estHour`, `left`, `assignedTo` 等

### CLI 实现

```javascript
// bin/zentao.js

// 1. 定义表单提交函数
async function formPost(path, data) {
  const url = `${baseUrl}${path}`;
  const params = new URLSearchParams(data);
  
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Cookie': cookie  // 或 Token
    },
    body: params.toString()
  });
  
  return response.json();
}

// 2. 实现命令
program
  .command('task create')
  .option('--execution <id>', '执行ID')
  .option('--name <name>', '任务名称')
  .option('--type <type>', '任务类型: devel, test, design, discuss')
  .action(async (opts) => {
    // 调用表单端点
    const result = await formPost(
      `/task-create-${opts.project}-${opts.execution}.html?T=json`,
      {
        name: opts.name,
        type: opts.type,
        estHour: opts.estimate || 0
      }
    );
    
    // 解析响应
    const match = String(result).match(/task-(\d+)\.html/);
    if (match) {
      console.log(`任务创建成功: ${match[1]}`);
    }
  });
```

### 常见表单端点模式

| 操作 | 端点模式 | 参数 |
|------|---------|------|
| 创建 | `/{resource}-create-{parent}.html?T=json` | 表单字段 |
| 编辑 | `/{resource}-edit-{id}.html?T=json` | 表单字段 |
| 状态变更 | `/{resource}-{action}-{id}.html?T=json` | 通常无参数 |
| 评论 | `/action-comment-{resource}-{id}.html?T=json` | `comment` |

---

## 验证方法

### 1. 单元测试

```javascript
// test/task.test.js

describe('Task Operations', () => {
  it('should create task via form', async () => {
    const result = await formPost('/task-create-1-340.html?T=json', {
      name: '测试任务',
      type: 'devel'
    });
    
    expect(result).toBeDefined();
    expect(String(result)).toMatch(/task-\d+\.html/);
  });
});
```

### 2. 集成测试

```bash
# 创建测试任务
node bin/zentao.js task create --execution 340 --name "TEST-TMP" --type devel

# 记录返回的任务 ID

# 验证任务存在
node bin/zentao.js tasks --execution 340 | grep "TEST-TMP"

# 清理：取消任务
node bin/zentao.js task cancel <taskId>
```

### 3. 数据隔离原则

⚠️ **重要**: 测试时使用独立数据，测试后恢复

```javascript
// 测试流程
async function testWithCleanup(testFn, cleanupFn) {
  const resourceId = await testFn();
  try {
    // 验证操作
    await verify(resourceId);
  } finally {
    // 无论成功失败，都清理
    await cleanupFn(resourceId);
  }
}

// 示例
testWithCleanup(
  () => createBug({ title: 'TEST-BUG-XXX' }),
  (id) => deleteBug(id)
);
```

---

## 常见问题排查

### 问题 1: 表单提交返回 HTML 而非 JSON

**原因**: `T=json` 参数缺失或服务端不支持

**解决**: 检查 URL 是否包含 `?T=json`

### 问题 2: CSRF Token 验证失败

**原因**: 表单提交需要 CSRF Token

**解决**: 
```javascript
// 1. 获取页面 HTML
const html = await fetch(pageUrl).then(r => r.text());

// 2. 提取 CSRF Token
const csrfMatch = html.match(/name="(\w+)" value="(\w+)"/);

// 3. 加入表单数据
data[csrfMatch[1]] = csrfMatch[2];
```

### 问题 3: 中文乱码

**原因**: 编码问题

**解决**:
```javascript
const params = new URLSearchParams();
for (const [key, value] of Object.entries(data)) {
  params.append(key, value);  // 自动处理编码
}
```

### 问题 4: Cookie vs Token

**场景**: REST API 用 Token，表单用 Cookie

**解决**: 
```javascript
// 方案 1: 用 Token 换 Cookie
async function loginWithToken(token) {
  const response = await fetch('/api/v1/tokens', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${token}` }
  });
  // 从 response.headers 提取 Set-Cookie
}

// 方案 2: 混合认证
const headers = {
  'Authorization': `Bearer ${token}`,
  'Cookie': cookie  // 两者都传
};
```

---

## 开发检查清单

### 新增功能前

- [ ] 查阅 REST API 文档，确认是否有对应接口
- [ ] 如果有 REST API，测试是否正常工作
- [ ] 如果 REST API 失败，准备用浏览器工具探测

### 探测阶段

- [ ] 使用浏览器手动执行操作
- [ ] Network 面板捕获请求
- [ ] 记录 URL、Method、Headers、Body
- [ ] 多次验证参数是否稳定

### 实现阶段

- [ ] 编写 CLI 命令
- [ ] 处理错误和边界情况
- [ ] 添加 --help 说明
- [ ] 更新 SKILL.md 文档

### 测试阶段

- [ ] 使用独立测试数据
- [ ] 验证操作成功
- [ ] 清理测试数据
- [ ] 更新 references/api-maintenance.md

---

## 相关工具文档

| 工具 | 文档 |
|------|------|
| opencli-browser | `~/.agents/skills/opencli-browser/SKILL.md` |
| playwright | 内置工具，无需 skill |
| chrome-devtools | `~/.agents/skills/chrome-cdp/SKILL.md` |

---

## 示例：从探测到实现

### 案例：任务开始功能

#### Step 1: 探测

```bash
# 1. 打开禅道任务页面
playwright_browser_navigate --url "http://10.240.1.200/task-view-123.html"

# 2. 点击"开始"按钮
playwright_browser_snapshot  # 找到按钮
playwright_browser_click --ref "button[name='start']"

# 3. 查看网络请求
playwright_browser_network_requests --requestBody true
```

#### Step 2: 分析

发现请求：
```
POST /task-start-123.html?T=json
Content-Type: application/x-www-form-urlencoded

(空 body)
```

响应：
```json
{"result": "success", "message": "操作成功"}
```

#### Step 3: 实现

```javascript
// bin/zentao.js
program
  .command('task start <id>')
  .action(async (id) => {
    const result = await formPost(`/task-start-${id}.html?T=json`, {});
    
    if (result.result === 'success') {
      console.log(`任务 ${id} 已开始`);
    } else {
      console.error(`操作失败: ${result.message}`);
    }
  });
```

#### Step 4: 验证

```bash
# 创建测试任务
node bin/zentao.js task create --execution 340 --name "TEST-START" --type devel

# 开始任务
node bin/zentao.js task start <id>

# 验证状态
node bin/zentao.js tasks --execution 340 | grep "TEST-START"

# 清理
node bin/zentao.js task cancel <id>
```

#### Step 5: 文档

更新 `references/api-maintenance.md`：
```markdown
| 开始任务 | `/task-start-{id}.html?T=json` | POST，空 body |
```
