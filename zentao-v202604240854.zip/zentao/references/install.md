# Zentao CLI 安装指引

当收到 `zentao-{version}.zip` 后按以下步骤完成安装。

## 步骤 1：检测环境

**macOS / Linux:**
```bash
cd zentao
./scripts/check-env.sh
```

**Windows:**
```cmd
cd zentao
scripts\check-env.bat
```

如果检测失败按提示安装 Node.js（需要 v18+）。

## 步骤 2：安装依赖

```bash
cd zentao/cli
npm install
```

## 步骤 3：获取 Token（自动保存到 .env）

```bash
cd zentao/cli
node bin/zentao.js token -a <用户名> -p <密码>
```

执行后会自动将 Token 保存到 `.env` 文件。

## 步骤 4：验证

```bash
node bin/zentao.js products
```

---

完整使用文档见 SKILL.md
维护参考见 references/api-maintenance.md