# 禅道项目管理最佳实践

基于快递100项目管理的实践经验，涵盖组织架构、迭代流程、效能分析、进度管理和个人工作流。

> **快速命令参考** 见 `SKILL.md`，本文档是方法论的详述。

---

## 一、组织架构

### 项目集 → 项目 → 执行 三层结构

```
项目集（年度规划）
  └── 项目（专项/日常迭代）
        └── 执行（具体迭代）
```

**当前组织**：
```
默认项目集
  ├── 2026日常迭代 (进行中)          ← 主战场
  │     ├── 20260106迭代 (已过期)
  │     ├── 20260512迭代 (进行中)     ← 当前迭代
  │     └── ...
  ├── API开放平台重构2025 (未开始)    ← 专项
  ├── C端寄件标品及新平台增长专项 (未开始)
  ├── 2025日常迭代 (进行中)
  ├── 鸿蒙-收件端 (进行中)
  └── 历史项目 (已关闭)
```

### 常用 ID 速查

同步缓存后，用以下命令快速查 ID：

```bash
zentao sync                        # 首次同步
zentao projects -f table           # 查项目 ID
zentao executions 312 -f table     # 查执行 ID
zentao products -f table           # 查产品 ID
```

---

## 二、迭代流程

### 1. 需求阶段

```
产品经理创建需求 → 评审 → 关联项目/执行
```

**需求状态流转**：
```
草稿(draft) → 激活(active) → 变更(changing) → 评审中(reviewing) → 完成(closed)
```

**CLI 操作**：
```bash
# 创建需求（需要指定产品 ID 和模块 ID）
zentao create story --title "需求标题" --product <id> --module <moduleId> --spec "详细描述"

# 提交评审
zentao story submitreview <id>

# 评审通过
zentao story review <id>

# 关联到执行（将需求纳入某次迭代）
zentao story link <id> --execution <executionId>

# 添加备注（补充说明、变更原因）
zentao story comment <id> --comment "备注内容"
```

> **注意**: 创建需求时 `--module` 参数如果不确定可省略（默认 0），但部分产品会报"所属模块不能为空"，此时需先用 API 查到模块 ID。

### 2. 任务阶段

```
项目经理/开发分解需求为任务 → 分配 → 开发/测试 → 完成
```

**任务状态流转**：
```
未开始(wait) → 进行中(doing) → 已完成(done)
            ↘ 已取消(cancel)
```

**CLI 操作**：
```bash
# 创建任务（指定执行 ID）
zentao task create --execution <id> --name "任务名" --type devel --estimate 8

# 开始任务
zentao task start <id>

# 记录工时（每日）
zentao task effort <id> --consumed 4 --comment "进度说明"

# 完成任务（需提交总工时）
zentao task finish <id> --consumed 8

# 取消任务
zentao task cancel <id>
```

**任务类型**：

| 类型 | 代码 | 说明 |
|------|------|------|
| 开发 | devel | 编码、重构 |
| 测试 | test | 测试用例执行 |
| 设计 | design | UI/UX/架构设计 |
| 研究 | study | 技术调研 |
| 讨论 | discuss | 会议、评审 |
| 事务 | affair | 行政、沟通 |
| 其他 | misc | 其他杂项 |

### 3. 测试阶段

```
测试人员创建 Bug → 开发解决 → 测试验证 → 关闭
```

**Bug 状态流转**：
```
激活(active) → 已确认(confirmed) → 已解决(resolved) → 已关闭(closed)
```

**CLI 操作**：
```bash
# 创建 Bug
zentao create bug --title "Bug标题" --product <id> --steps "复现步骤"

# 解决 Bug
zentao update bug <id> --status resolved --resolution fixed --comment "已修复"

# 关闭 Bug
zentao update bug <id> --status closed
```

**Bug 解决方案**：

| 方案 | 代码 | 说明 |
|------|------|------|
| 已修复 | fixed | 代码修复 |
| 设计如此 | bydesign | 非Bug |
| 重复 | duplicate | 已有相同Bug |
| 外部原因 | external | 第三方问题 |
| 无法重现 | notrepro | 无法复现 |
| 延期处理 | postponed | 推迟到下个版本 |
| 不予解决 | willnotfix | 不计划修复 |

---

## 三、效能分析与统计

### 3.1 项目健康度指标

| 指标 | 计算方式 | 健康值 | 告警值 |
|------|---------|--------|--------|
| 需求完成率 | 已完成/总需求 | > 90% | < 70% |
| Bug 修复率 | 已解决/总Bug | > 95% | < 80% |
| 任务完成率 | 已完成/总任务 | > 90% | < 70% |
| 工时偏差 | 实际/预估 | 80%-120% | <50% 或 >200% |
| Bug 重开率 | 重开/已解决 | < 5% | > 15% |

### 3.2 用 CLI 做效能分析

#### 个人效能

```bash
# 看某人的任务分布（谁在干什么）
zentao tasks --execution <id> -f table

# 看某人的 Bug 解决情况
zentao bugs --product <id> -f table
```

#### 团队效能

```bash
# 任务进度报告（完成率、按状态分布、按指派人分布）
zentao report tasks --execution <id>
# 输出示例：
# { byStatus: { wait: 10, doing: 6, done: 58 },
#   byAssignee: { 张三: 12, 李四: 8, ... },
#   progress: { total: 74, done: 58, percent: 78.4 } }

# Bug 统计报告（按状态、严重程度、指派人分布）
zentao report bugs --product <id>
# 输出示例：
# { byStatus: { active: 5, resolved: 15, closed: 52, total: 72 },
#   bySeverity: { 1: 2, 2: 5, 3: 45, 4: 20 },
#   byAssignee: { 张三: 8, 李四: 12, ... } }

# 需求统计（按状态分布）
zentao report stories --product <id>
# 输出示例：
# { byStatus: { active: 455, reviewing: 22, draft: 22 } }
```

#### 可视化图表

```bash
# Bug 统计看板（饼图+柱状图+汇总卡片）
zentao chart bugs --product <id>

# 任务进度条
zentao chart tasks --execution <id>

# 项目进度总览
zentao chart progress

# Bug 趋势（30天新增 vs 解决）
zentao chart trend --product <id> --days 30
```

### 3.3 数据导出与深度分析

当 CLI 内置报告不够用时，导出到 Excel/JSON 做自定义分析：

```bash
# 导出全量数据
zentao export stories --product <id> --as excel
zentao export tasks --execution <id> --as csv
zentao export bugs --product <id> --as json

# 导出产品列表（做项目地图）
zentao export products --as excel
```

**常见分析场景**：

| 场景 | 数据源 | 分析方法 |
|------|--------|---------|
| 需求吞吐量 | export stories | 按周/月统计新建vs完成数 |
| Bug 密度 | export bugs | Bug数/需求数 按产品对比 |
| 工时偏差 | export tasks | (实际工时-预估工时)/预估工时 |
| 交付速率 | export stories | 按迭代统计完成需求数 |
| 测试覆盖率 | testcase + bugs | 用例数/需求数 |

### 3.4 进度管理方法论

#### 迭代进度跟踪

```bash
# 每日晨会前快速查看
zentao chart tasks --execution <id>
zentao report tasks --execution <id>
```

关键看三个信号：
1. **wait 占比过高** → 任务卡在分配环节，需要拆分或重新分配
2. **doing 长期不变** → 可能有阻塞，需要跟进
3. **done 增长过慢** → 评估是否需要加人或砍需求

#### Bug 趋势管理

```bash
# 每周查看 Bug 趋势
zentao chart trend --product <id> --days 30
```

关键看两个趋势：
1. **新增 > 解决 连续 3 天** → 质量恶化信号，需要收敛
2. **净增为负** → 债务在减少，趋势健康

#### 多项目健康度总览

```bash
# 一览所有项目状态
zentao chart progress

# 针对重点项目深入
zentao executions <projectId> -f table
zentao report tasks --execution <currentExecutionId>
```

---

## 四、角色工作流

不同角色用不同的命令组合融入日常工作。

### 4.1 产品经理 (PO/PM)

**核心关注**：需求质量、交付进度、用户反馈

#### 每日工作流

```bash
# 1. 晨会前：查看当前迭代需求状态
zentao stories --product <id> -f table
zentao report stories --product <id>

# 2. 评审会：提交并评审需求
zentao story submitreview <id>         # 提交评审
zentao story review <id>               # 评审通过

# 3. 规划：关联需求到迭代
zentao executions <projectId> -f table # 看当前迭代
zentao story link <id> --execution <id> # 关联到迭代

# 4. 进度跟踪
zentao chart tasks --execution <id>     # 任务完成率
zentao chart trend --product <id>       # Bug 趋势
```

#### 需求管理最佳实践

```bash
# 创建高质量需求（标题用【模块】前缀）
zentao create story \
  --title "【用户中心】新增手机号绑定功能" \
  --product 37 \
  --module 2779 \
  --spec "## 背景\n用户需要绑定手机号以接收物流通知\n## 验收标准\n1. 支持短信验证码\n2. 支持更换绑定\n## 关联设计\n[设计稿链接]"
```

### 4.2 开发人员 (Dev)

**核心关注**：待办任务、状态更新、工时记录

#### 每日工作流

```bash
# 1. 早上：查看当前迭代任务
zentao tasks --execution <id> -f table

# 2. 开始任务
zentao task start <id>

# 3. 开发中：记录工时（建议每天下班前记录）
zentao task effort <id> --consumed 4 --comment "完成了接口开发"

# 4. 完成任务
zentao task finish <id> --consumed 8

# 5. 解决分配给自己的 Bug
zentao update bug <id> --status resolved --resolution fixed --comment "已在 PR#123 修复"
```

#### 一次完整开发流程

```bash
# Day 1: 接到需求
zentao task start <taskId>                          # 开始
zentao task effort <taskId> --consumed 2 --comment "技术方案设计"

# Day 2-3: 编码
zentao task effort <taskId> --consumed 6 --comment "核心功能开发完成"
zentao task comment <taskId> --comment "遇到XX问题，预计多1天"

# Day 4: 联调完成
zentao task effort <taskId> --consumed 8 --comment "联调通过，提交测试"
zentao task finish <taskId> --consumed 16            # 完成（总计 16h）

# Day 5: 修 Bug
zentao update bug <bugId> --status resolved --resolution fixed --comment "根因: XX, 修复方式: YY"
```

### 4.3 测试人员 (QA)

**核心关注**：Bug 全生命周期、测试覆盖、回归验证

#### 每日工作流

```bash
# 1. 早上：查看待验证 Bug 和活跃 Bug
zentao bugs --product <id> -f table
zentao chart bugs --product <id>                     # Bug 看板

# 2. 创建 Bug（复现步骤要详细）
zentao create bug \
  --title "【登录】验证码发送失败" \
  --product <id> \
  --steps "1. 打开登录页\n2. 输入手机号 13800138000\n3. 点击发送验证码\n4. 期望：收到短信\n5. 实际：提示'发送失败'"

# 3. 验证已修复的 Bug
zentao update bug <id> --status closed               # 验证通过则关闭

# 4. 创建测试用例
zentao testcase create --title "登录-正常流程" --product <id> --steps "1. 输入正确手机号\n2. 输入验证码\n3. 验证登录成功"

# 5. 周末/月末统计
zentao report bugs --product <id>                    # Bug 统计
zentao chart trend --product <id> --days 30          # 趋势图
```

#### Bug 管理最佳实践

- **标题规范**：`【模块】简短问题描述`
- **复现步骤**：必须是可执行的，标注预期结果和实际结果
- **严重程度**：
  - 1 = 致命（系统崩溃、数据丢失）
  - 2 = 严重（功能不可用、流程阻断）
  - 3 = 一般（功能异常但有替代方案）
  - 4 = 轻微（UI问题、体验优化）

### 4.4 设计师 (UI/UX)

**核心关注**：设计需求、评审反馈、设计稿交付

#### 工作流

```bash
# 查看设计相关需求
zentao stories --product <id> -f table

# 评审时添加设计备注
zentao story comment <id> --comment "设计稿已上传至 [链接]，请查看"

# 创建设计任务
zentao task create --execution <id> --name "XX模块-UI设计" --type design --estimate 16

# 更新设计进度
zentao task start <id>
zentao task effort <id> --consumed 4 --comment "初稿完成"
zentao task finish <id> --consumed 12
```

---

## 五、缓存与同步

### 5.1 何时同步

| 场景 | 命令 | 说明 |
|------|------|------|
| 首次使用 | `zentao sync` | 拉取全量基础数据 |
| 日常使用 | 自动 | 命令执行时自动判断缓存是否过期 |
| 数据过期 | `zentao sync --clear` | 清除缓存重新拉取 |
| 只更新用户 | `zentao sync --type users` | 只同步指定类型 |

### 5.2 缓存策略

| 数据类型 | 变化频率 | 缓存 TTL | 建议 |
|----------|---------|---------|------|
| 产品 | 几乎不变 | 7 天 | 缓存 |
| 项目 | 季度级 | 3 天 | 缓存 |
| 用户/角色 | 月级 | 7 天 | 缓存 |
| 执行/迭代 | 双周级 | 1 天 | 缓存 + `--refresh` |
| 项目集 | 几乎不变 | 7 天 | 缓存 |
| 需求 | 日级 | 无 | 实时查询 |
| 任务 | 日级 | 无 | 实时查询 |
| Bug | 日级 | 无 | 实时查询 |

### 5.3 缓存加速效果

```bash
# 首次：调 API (~200ms)
zentao products -f table

# 缓存命中：读本地文件 (~5ms)
zentao products -f table

# 强制刷新
zentao products --refresh -f table
```

---

## 六、自动化场景

### 6.1 数据准备

```bash
# 同步基础数据（建议每天/每周执行一次）
zentao sync

# 只同步特定类型
zentao sync --type products,users
```

### 6.2 周报生成

```bash
# 导出本周完成的任务
zentao export tasks --execution <id> --as excel

# 导出本周 Bug 处理情况
zentao export bugs --product <id> --as excel
```

### 6.3 进度跟踪

```bash
# 生成任务完成率图表
zentao chart tasks --execution <id>

# 生成 Bug 趋势图
zentao chart trend --product <id> --days 30

# 项目总览
zentao chart progress
```

### 6.4 数据备份

```bash
# 导出全量数据
zentao export stories --product <id> --as json
zentao export bugs --product <id> --as json
zentao export tasks --execution <id> --as json
```

---

## 七、命名规范

| 对象 | 规范 | 示例 |
|------|------|------|
| 项目 | `{年份}日常迭代` / `{专项名称}` | 2026日常迭代、API开放平台重构2025 |
| 执行 | `{年份}{月日}迭代` / `{里程碑}` | 20260512迭代、V3.0发布 |
| 需求 | `【模块】功能描述` | 【用户中心】新增手机号绑定 |
| 任务 | `{模块}-{功能}-{阶段}` | 用户中心-登录-开发 |
| Bug | `【模块】问题描述` | 【登录】验证码发送失败 |
| 用例 | `{模块}-{场景}-{类型}` | 登录-手机号-正常流程 |

---

## 八、注意事项

1. **API 限制**: 禅道 REST API v1 部分功能不可用（任务创建/状态变更需用表单方式）
2. **权限控制**: 不同角色看到的数据范围不同，CLI 使用当前 Token 对应用户的权限
3. **数据隔离**: 测试时创建独立数据，测试完及时清理
4. **工时准确性**: 及时记录工时，避免事后批量补录
5. **状态同步**: 任务完成后及时更新状态，保证项目数据准确
6. **缓存机制**: 稳定数据自动缓存，过期自动刷新；需求/任务/Bug 始终实时查询

---

## 相关文档

- `SKILL.md` - 快速命令参考卡片
- `api-maintenance.md` - API 限制和维护指南
- `development-guide.md` - 二次开发指南
- `install.md` - 安装指引
