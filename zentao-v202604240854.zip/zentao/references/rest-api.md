# 禅道 REST API 完整文档

> 来源：http://10.240.1.200/dev-api-restapi.html
> 版本：企业版 8.11
> 更新时间：2026-04-23

## 基础信息

- **Base URL**: `http://10.240.1.200/api.php/v1`
- **认证方式**: Token (Header: `Token: xxx`)
- **Content-Type**: `application/json`

---

## 认证模块 (Token)

### 获取 Token

**POST** `/tokens`

用账号密码换取 API Token，Token 有效期默认 30 天。

**请求体**:
```json
{
  "account": "用户名",
  "password": "密码"
}
```

**响应**:
```json
{
  "token": "cuejkiesahl9k1j8be5bv5lndo"
}
```

---

## 用户模块 (User)

| API | 方法 | 端点 |
|-----|------|------|
| 获取用户列表 | GET | `/users` |
| 获取用户信息 | GET | `/users/:id` |
| 获取我的个人信息 | GET | `/user` |
| 创建用户 | POST | `/users` |
| 修改用户信息 | PUT | `/users/:id` |
| 删除用户 | DELETE | `/users/:id` |

**创建用户请求体**:
```json
{
  "account": "登录名",
  "password": "密码",
  "realname": "真实姓名",
  "role": "top|dev|qa|pm|po|td|pd|qd|others",
  "group": "权限组ID"
}
```

---

## 项目集模块 (Program)

| API | 方法 | 端点 |
|-----|------|------|
| 获取项目集列表 | GET | `/programs` |
| 获取项目集详情 | GET | `/programs/:id` |
| 创建项目集 | POST | `/programs` |
| 修改项目集 | PUT | `/programs/:id` |
| 删除项目集 | DELETE | `/programs/:id` |

---

## 产品模块 (Product)

| API | 方法 | 端点 |
|-----|------|------|
| 获取产品列表 | GET | `/products` |
| 获取产品详情 | GET | `/products/:id` |
| 创建产品 | POST | `/products` |
| 编辑产品 | PUT | `/products/:id` |
| 删除产品 | DELETE | `/products/:id` |

**创建产品请求体**:
```json
{
  "name": "产品名称",
  "code": "产品代号",
  "line": "产品线ID",
  "PO": "产品负责人账号",
  "QD": "测试负责人账号",
  "RD": "发布负责人账号",
  "desc": "产品描述"
}
```

---

## 产品计划模块 (Plan)

| API | 方法 | 端点 |
|-----|------|------|
| 获取产品计划列表 | GET | `/products/:id/plans` |
| 获取计划详情 | GET | `/plans/:id` |
| 创建计划 | POST | `/products/:id/plans` |
| 修改计划 | PUT | `/plans/:id` |
| 删除计划 | DELETE | `/plans/:id` |
| 产品计划关联需求 | POST | `/plans/:id/stories` |
| 产品计划取消关联需求 | DELETE | `/plans/:id/stories` |
| 产品计划关联Bug | POST | `/plans/:id/bugs` |
| 产品计划取消关联Bug | DELETE | `/plans/:id/bugs` |

---

## 发布模块 (Release)

| API | 方法 | 端点 |
|-----|------|------|
| 获取项目发布列表 | GET | `/projects/:id/releases` |
| 获取产品发布列表 | GET | `/products/:id/releases` |

---

## 需求模块 (Story)

| API | 方法 | 端点 |
|-----|------|------|
| 获取项目需求列表 | GET | `/projects/:id/stories` |
| 获取产品需求列表 | GET | `/products/:id/stories` |
| 获取执行需求列表 | GET | `/executions/:id/stories` |
| 获取需求详情 | GET | `/stories/:id` |
| 创建需求 | POST | `/products/:id/stories` |
| 变更需求 | PUT | `/stories/:id/change` |
| 修改需求其他字段 | PUT | `/stories/:id` |
| 删除需求 | DELETE | `/stories/:id` |

**创建需求请求体**:
```json
{
  "title": "需求标题",
  "spec": "需求描述",
  "pri": "优先级(1-4)",
  "estimate": "预计工时",
  "module": "模块ID",
  "plan": "计划ID"
}
```

---

## 项目模块 (Project)

| API | 方法 | 端点 |
|-----|------|------|
| 获取项目列表 | GET | `/projects` |
| 获取项目详情 | GET | `/projects/:id` |
| 创建项目 | POST | `/projects` |
| 修改项目 | PUT | `/projects/:id` |
| 删除项目 | DELETE | `/projects/:id` |

**创建项目请求体**:
```json
{
  "name": "项目名称",
  "code": "项目代号",
  "begin": "开始日期",
  "end": "结束日期",
  "PM": "项目经理账号",
  "desc": "项目描述"
}
```

---

## 版本模块 (Build)

| API | 方法 | 端点 |
|-----|------|------|
| 获取项目版本列表 | GET | `/projects/:id/builds` |
| 获取执行版本列表 | GET | `/executions/:id/builds` |
| 获取版本详情 | GET | `/builds/:id` |
| 创建版本 | POST | `/projects/:id/builds` |
| 修改版本 | PUT | `/builds/:id` |
| 删除版本 | DELETE | `/builds/:id` |

---

## 执行模块 (Execution)

| API | 方法 | 端点 |
|-----|------|------|
| 获取项目的执行列表 | GET | `/projects/:id/executions` |
| 查看执行详情 | GET | `/executions/:id` |
| 创建执行 | POST | `/projects/:id/executions` |
| 修改执行 | PUT | `/executions/:id` |
| 删除执行 | DELETE | `/executions/:id` |

---

## 任务模块 (Task)

| API | 方法 | 端点 |
|-----|------|------|
| 获取执行任务列表 | GET | `/executions/:id/tasks` |
| 获取任务详情 | GET | `/tasks/:id` |
| 创建任务 | POST | `/executions/:id/tasks` |
| 修改任务 | PUT | `/tasks/:id` |
| 删除任务 | DELETE | `/tasks/:id` |

**创建任务请求体**:
```json
{
  "name": "任务名称",
  "type": "devel|design|test|study|discuss|ui|affair|misc",
  "pri": "优先级(1-4)",
  "estimate": "预计工时",
  "assignedTo": "指派给账号",
  "desc": "描述"
}
```

---

## Bug 模块 (Bug)

| API | 方法 | 端点 |
|-----|------|------|
| 获取产品Bug列表 | GET | `/products/:id/bugs` |
| 获取Bug详情 | GET | `/bugs/:id` |
| 创建Bug | POST | `/products/:id/bugs` |
| 修改Bug | PUT | `/bugs/:id` |
| 删除Bug | DELETE | `/bugs/:id` |

**创建Bug请求体**:
```json
{
  "title": "Bug标题",
  "severity": "严重程度(1-4)",
  "pri": "优先级(1-4)",
  "steps": "重现步骤",
  "assignedTo": "指派给账号",
  "module": "模块ID",
  "execution": "执行ID"
}
```

---

## 用例模块 (Testcase)

| API | 方法 | 端点 |
|-----|------|------|
| 获取产品用例列表 | GET | `/products/:id/testcases` |
| 获取用例详情 | GET | `/testcases/:id` |
| 创建用例 | POST | `/products/:id/testcases` |
| 修改用例 | PUT | `/testcases/:id` |
| 删除用例 | DELETE | `/testcases/:id` |

---

## 测试单模块 (Testtask)

| API | 方法 | 端点 |
|-----|------|------|
| 获取测试单列表 | GET | `/testtasks` |
| 获取项目的测试单 | GET | `/projects/:id/testtasks` |
| 获取测试单详情 | GET | `/testtasks/:id` |

---

## 反馈模块 (Feedback)

| API | 方法 | 端点 |
|-----|------|------|
| 获取反馈列表 | GET | `/feedbacks` |
| 获取反馈详情 | GET | `/feedbacks/:id` |
| 创建反馈 | POST | `/feedbacks` |
| 修改反馈 | PUT | `/feedbacks/:id` |
| 删除反馈 | DELETE | `/feedbacks/:id` |
| 指派反馈 | PUT | `/feedbacks/:id/assignTo` |
| 关闭反馈 | PUT | `/feedbacks/:id/close` |

---

## 工单模块 (Ticket)

| API | 方法 | 端点 |
|-----|------|------|
| 获取工单列表 | GET | `/tickets` |
| 获取工单详情 | GET | `/tickets/:id` |
| 创建工单 | POST | `/tickets` |
| 修改工单 | PUT | `/tickets/:id` |
| 删除工单 | DELETE | `/tickets/:id` |

---

## 通用字段说明

### 优先级 (pri)
- 1: 最高
- 2: 较高
- 3: 正常
- 4: 较低

### Bug 严重程度 (severity)
- 1: 致命
- 2: 严重
- 3: 一般
- 4: 建议

### 用户角色 (role)
- top: 高层管理
- dev: 研发
- qa: 测试
- pm: 项目经理
- po: 产品经理
- td: 技术总监
- pd: 产品总监
- qd: 测试总监
- others: 其他

### 任务类型 (type)
- devel: 开发
- design: 设计
- test: 测试
- study: 研究
- discuss: 讨论
- ui: 界面
- affair: 事务
- misc: 其他

---

## 使用示例

```bash
# 1. 获取 Token
TOKEN=$(curl -s -X POST "http://10.240.1.200/api.php/v1/tokens" \
  -H "Content-Type: application/json" \
  -d '{"account": "your_account", "password": "your_password"}' \
  | jq -r '.token')

# 2. 获取产品列表
curl -s -H "Token: $TOKEN" "http://10.240.1.200/api.php/v1/products" | jq .

# 3. 获取项目详情
curl -s -H "Token: $TOKEN" "http://10.240.1.200/api.php/v1/projects/312" | jq .

# 4. 创建需求
curl -s -X POST "http://10.240.1.200/api.php/v1/products/25/stories" \
  -H "Token: $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"title": "新功能", "spec": "描述", "pri": 3}' | jq .
```

---

## 错误响应

```json
{
  "error": "错误信息描述"
}
```

常见错误：
- 401 Unauthorized: Token 无效或过期
- 403 Forbidden: 无权限访问
- 404 Not Found: 资源不存在
