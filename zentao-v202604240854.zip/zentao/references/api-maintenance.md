# 禅道 API 维护指南

本文档记录禅道 API 的已知限制和维护注意事项，供后续开发和维护参考。

## REST API 状态矩阵

| 资源 | 查询 | 创建 | 更新 | 删除 | 状态变更 | 备注 |
|------|------|------|------|------|---------|------|
| 产品 | ✅ | - | - | - | - | 只读 |
| 项目 | ✅ | - | - | - | - | 只读 |
| 执行 | ✅ | - | - | - | - | 只读 |
| 需求 | ✅ | ✅ | ⚠️ | ✅ | ✅ | 创建可用，更新有问题 |
| 任务 | ✅ | ❌ | ❌ | - | ✅ | REST API 有 BUG，需用表单 |
| Bug | ✅ | ✅ | ✅ | - | ✅ | 完整支持 |
| 用例 | ✅ | ✅ | - | ✅ | - | 创建/删除可用 |
| 版本 | ✅ | - | - | - | - | 只读 |

## 需要使用传统表单方式的功能

由于禅道 REST API v1 存在 BUG，以下功能必须通过 HTML 表单提交实现：

### 任务相关

| 操作 | 表单端点 | 说明 |
|------|---------|------|
| 创建任务 | `/task-create-{project}-{execution}.html` | REST API 会报 Fatal error |
| 开始任务 | `/task-start-{id}.html` | |
| 完成任务 | `/task-finish-{id}.html` | |
| 取消任务 | `/task-cancel-{id}.html` | |
| 任���备注 | `/action-comment-task-{id}.html` | |
| 工时记录 | `/effort-createForObject-task-{id}.html` | |

### 需求相关

| 操作 | 表单端点 | 说明 |
|------|---------|------|
| 需求备注 | `/action-comment-story-{id}.html` | |
| 提交评审 | `/story-submitReview-{id}-story.html` | |
| 评审通过 | `/story-review-{id}-story.html` | |
| 关联执行 | `/story-linkExecution-{id}.html` | |
| 关联项目 | `/story-linkStory-{id}.html` | |

## 已知的 REST API 问题

### 1. 任务创建 API 返回 500

**现象**: 调用 `POST /executions/{id}/tasks` 返回 Fatal error
**原因**: 禅道 REST API v1 的 tasksEndpoint::post() 有 BUG
**解决方案**: 使用表单方式 `/task-create-{project}-{execution}.html`

### 2. 需求更新 API

**现象**: 调用 `PUT /stories/{id}` 可能无法更新所有字段
**建议**: 使用表单页面更新或通过状态变更间接更新

### 3. 表单提交格式

使用 `formPost` 函数而非 `client.request`:

```javascript
// 正确方式 - 表单提交
const result = await formPost(`/task-create-${project}-${execution}.html?T=json`, {
  name: '任务名称',
  type: 'devel',
  estHours: 8
});

// 错误方式 - REST API
const result = await sdk.client.request('POST', `/executions/${executionId}/tasks`, {...})
```

## 后续探索方法

如需探索新的 API 或发现新问题：

### 方法 1: 使用 opencli 浏览器工具

```bash
# 登录禅道，手动操作，观察 Network 面板
# 找到对应的 API 调用或表单提交
```

### 方法 2: 使用 curl 测试

```bash
# 测试 REST API
curl -X POST "http://10.240.1.200/api/v1/tasks" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name": "test"}'

# 测试表单提交
curl -X POST "http://10.240.1.200/task-create-1-340.html" \
  -H "Cookie: $COOKIE" \
  -d "name=test&type=devel"
```

### 方法 3: 查阅禅道源码

禅道企业版的 API 实现位于:
- `module/api/std/classes/` - REST API 入口
- `module/task/control.php` - 任务控制器（含表单处理）
- `module/story/control.php` - 需求控制器

## 常用表单端点参考

### Bug 操作

| 操作 | 端点 | 方法 |
|------|------|------|
| 解决 Bug | `/bug-resolve-{id}.html` | POST |
| 关闭 Bug | `/bug-close-{id}.html` | POST |
| 激活 Bug | `/bug-activate-{id}.html` | POST |

### 项目操作

| 操作 | 端点 | 方法 |
|------|------|------|
| 创建执行 | `/execution-create-{project}.html` | POST |
| 关联团队 | `/team-{project}-link.html` | POST |

### 工时相关

| 操作 | 端点 | 方法 |
|------|------|------|
| 记录工时 | `/effort-createForObject-{object}-{id}.html` | POST |
| 我的工时 | `/effort-createForObject-mytask.html` | GET |

## 维护检查清单

添加新功能时：

- [ ] 首先尝试 REST API
- [ ] 如果 REST API 失败，检查是否需要使用表单方式
- [ ] 使用 opencli 浏览器工具验证实际请求
- [ ] 测试成功后更新本文档
- [ ] 确保 CLI 有清晰的错误提示

## 相关文件

- `cli/src/client.js` - HTTP 客户端（支持 REST 和表单）
- `cli/src/cache.js` - 缓存管理器（分文件存储 + TTL 过期）
- `cli/src/utils.js` - 工具函数（extractItems, formatTable 等）
- `cli/bin/zentao.js` - 所有命令实现
- `cli/src/resources/` - 各资源模块

## 已修复的代码问题

### 1. bugs.js 的 listByProduct 方法 ✅ 已修复

**位置**: `cli/src/resources/bugs.js:8`

**原问题**: `listByProduct` 方法错误调用了 `getProducts()` 而不是获取产品下的 Bug

**已修复**: 现在正确调用 `/products/${productId}/bugs` 接口：
```javascript
async listByProduct(productId, params = {}) {
  return this.client.request('GET', `/products/${productId}/bugs`, null, { params });
}
```

> **注意**: CLI 的 `bugs --product <id>` 命令实际走的是 `products.listBugs()`，而非 `bugs.listByProduct()`。两者路径不同但结果一致。

---

## 需要修复的已知问题

### 2. 硬编码值（维护风险）

**位置**: `cli/bin/zentao.js`

- 模块 ID 默认为 `'0'`（create story 命令的 --module 参数）
- `openedBuild: 'trunk'` 硬编码

**建议**: 改为可配置或添加命令行参数

### 3. 分页响应解析

**位置**: `cli/src/utils.js:107` (`extractItems` 函数)

```javascript
function extractItems(data) {
  if (Array.isArray(data)) return data;
  if (data && typeof data === 'object') {
    for (const key of Object.keys(data)) {
      if (Array.isArray(data[key])) return data[key];
    }
  }
  return [data];
}
```

**注意**: 取第一个数组属性。禅道 REST API 的分页响应格式为 `{ page, total, limit, <resource>: [...] }`，通常只有一个数组字段，实际使用中未出现问题。

### 4. 任务创建 ID 提取不准确

**位置**: `cli/bin/zentao.js` (task create 命令)

```javascript
const match = String(result).match(/task-(\d+)\.html/);
```

**问题**: formPost 返回完整 HTML 页面而非 JSON 重定向，正则匹配到的可能是执行 ID 而非任务 ID。

### 5. CLI 缺少 Bug 删除命令

**问题**: `client.js` 实现了 `DELETE /bugs/{id}`，但 CLI 没有暴露 `delete bug` 命令

---

## 维护检查清单