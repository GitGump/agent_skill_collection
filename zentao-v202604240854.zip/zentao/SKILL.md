---
name: zentao
description: 禅道项目管理系统的 CLI 工具。支持完整的 CRUD 操作：查询/创建/更新/删除产品、项目、需求、任务、Bug、用例、版本等数据。支持需求评论、提交评审、任务状态变更(开始/完成/取消)、工时记录、数据导出 Excel/CSV/JSON、可视化图表和报告。当用户提到"禅道"、"zentao"、"项目数据"、"Bug统计"、"需求列表"、"任务进度"、"创建需求"、"创建Bug"、"分配任务"、"工时记录"、"提交评审"时必须使用此技能。
compatibility: Node.js 18+
---

# Zentao CLI 技能

禅道项目管理系统命令行工具。支持 CRUD 操作、状态流转、数据导出和分析可视化。

## 参考文档

| 文档 | 内容 |
|------|------|
| `references/best-practices.md` | **角色工作流、效能分析、进度管理、命名规范** — 详细方法论 |
| `references/api-maintenance.md` | REST API 限制、已知 BUG、传统表单方式 |
| `references/development-guide.md` | 二次开发、浏览器探测、开发检查清单 |
| `references/install.md` | 安装指引 |

---

## 安装与初始化

```bash
cd zentao/cli && npm install                     # 安装依赖
node bin/zentao.js token -a <用户名> -p <密码>    # 获取 Token（自动保存到 .env）
node bin/zentao.js sync                           # 首次同步基础数据到缓存
```

> 环境检测: `cd zentao && ./scripts/check-env.sh` (macOS/Linux) 或 `scripts\check-env.bat` (Windows)

---

## 命令速查

### 缓存与同步

```bash
zentao sync                              # 同步基础数据（产品/项目/用户/执行）
zentao sync --type products,users        # 只同步指定类型
zentao sync --full                       # 全量同步（含已关闭项目）
zentao sync --clear                      # 清除缓存后重新同步
zentao <cmd> --refresh                   # 强制刷新某个命令的缓存
```

> 产品(7d)、项目(3d)、用户(7d)、执行(1d) 自动缓存；需求/任务/Bug 实时查询。

### 查询

```bash
zentao products                          # 产品列表
zentao projects                          # 项目列表
zentao executions <projectId>            # 执行/迭代列表
zentao programs                          # 项目集列表
zentao users                             # 用户列表（全量分页）
zentao stories --product <id>            # 需求列表
zentao tasks --execution <id>            # 任务列表
zentao bugs --product <id>               # Bug 列表
zentao versions <projectId>              # 版本列表
zentao plans --product <id>              # 产品计划
zentao releases --product <id>           # 发布列表
zentao profile                           # 当前用户信息
```

所有查询命令支持 `-f table` 表格输出和 `--refresh` 强制刷新缓存。

### 创建

```bash
zentao create story --title "标题" --product <id> --spec "描述"
zentao create bug --title "标题" --product <id> --steps "复现步骤"
zentao task create --execution <id> --name "任务名" --type devel --estimate 8
zentao testcase create --title "标题" --product <id> --steps "步骤"
```

### 状态变更

```bash
# 任务
zentao task start <id>                           # 开始
zentao task finish <id> --consumed 8             # 完成
zentao task cancel <id>                          # 取消
zentao task effort <id> --consumed 2             # 记录工时
zentao task comment <id> --comment "备注"         # 添加备注

# 需求
zentao story comment <id> --comment "备注"        # 添加备注
zentao story submitreview <id>                   # 提交评审
zentao story review <id>                         # 评审通过
zentao story link <id> --execution <id>          # 关联执行

# Bug
zentao update bug <id> --status resolved --resolution fixed --comment "已修复"
zentao update bug <id> --status closed
```

### 分析报告

```bash
zentao report bugs --product <id>        # Bug 按状态/严重程度/指派人
zentao report tasks --execution <id>     # 任务进度、按状态/指派人
zentao report stories --product <id>     # 需求按状态分布
zentao report trend --product <id>       # Bug 趋势（默认30天）
```

### 可视化图表

```bash
zentao chart bugs --product <id>         # Bug 饼图+柱状图+汇总
zentao chart tasks --execution <id>      # 任务进度条+分布
zentao chart progress                    # 项目进度总览
zentao chart trend --product <id>        # Bug 趋势折线图
```

### 导出

```bash
zentao export products --as excel        # Excel (.xlsx)
zentao export stories --product <id> --as csv    # CSV
zentao export tasks --execution <id> --as json   # JSON
zentao export bugs --product <id> --as excel     # 指定输出目录: --output ./exports
```

### 删除

```bash
zentao testcase delete <id>              # 删除用例
```

---

## API 能力矩阵

| 对象 | 查询 | 创建 | 更新 | 删除 | 状态变更 | 评论 | 工时 |
|------|------|------|------|------|---------|------|------|
| 产品 | ✅ | - | - | - | - | - | - |
| 项目 | ✅ | - | - | - | - | - | - |
| 执行 | ✅ | - | - | - | - | - | - |
| 需求 | ✅ | ✅ | ⚠️ | ✅ | ✅ | ✅ | ✅ |
| 任务 | ✅ | ✅ | ⚠️ | - | ✅ | ✅ | ✅ |
| Bug | ✅ | ✅ | ✅ | - | ✅ | ✅ | - |
| 用例 | ✅ | ✅ | - | ✅ | - | - | - |

---

## 故障排查

```bash
# Token 过期 → 自动刷新（需 .env 中有 ZENTAO_ACCOUNT 和 ZENTAO_PASSWORD）
node bin/zentao.js token

# 依赖问题
cd zentao/cli && rm -rf node_modules && npm install

# API 连接失败 → 检查 .env 中的 ZENTAO_URL
```

---

## 文件结构

```
zentao/
├── SKILL.md                  # 本文档（命令速查卡片）
├── references/
│   ├── best-practices.md     # 角色工作流、效能分析、进度管理
│   ├── api-maintenance.md    # API 限制和维护信息
│   ├── development-guide.md  # 二次开发指南
│   └── install.md            # 安装指引
├── data/                     # 本地缓存（zentao sync 自动生成）
├── scripts/                  # 环境检测和打包脚本
└── cli/
    ├── bin/zentao.js         # CLI 入口
    └── src/
        ├── cache.js          # 缓存管理器（TTL 过期）
        ├── utils.js          # 工具函数（extractItems 等）
        ├── export.js         # 数据导出
        ├── visualize.js      # 可视化图表
        ├── client.js         # HTTP 客户端
        └── resources/        # 各资源模块
```
