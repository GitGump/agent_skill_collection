@echo off
REM 环境检测脚本 (Windows)
REM 用法: scripts\check-env.bat

echo ======================================
echo  Zentao CLI 环境检测
echo ======================================
echo.

set ERRORS=0

REM 检测 Node.js
echo [1/3] 检测 Node.js...
where node >nul 2>&1
if %ERRORLEVEL% equ 0 (
  for /f "tokens=*" %%a in ('node --version 2^>nul') do set NODE_VERSION=%%a
  echo   OK Node.js !NODE_VERSION!
  
  REM 检测版本号是否 >= 18
  set NODE_MAJOR=!NODE_VERSION:~1,2!
  if !NODE_MAJOR! geq 18 (
    echo   满足 v18+ 要求
  ) else (
    echo   X 需要 v18 或更高版本
    set /a ERRORS+=1
  )
) else (
  echo   X 未安装 Node.js
  set /a ERRORS+=1
)

echo.
echo [2/3] 检测 npm...
where npm >nul 2>&1
if %ERRORLEVEL% equ 0 (
  for /f "tokens=*" %%a in ('npm --version 2^>nul') do set NPM_VERSION=%%a
  echo   OK npm v!NPM_VERSION!
) else (
  echo   X 未安装 npm
  set /a ERRORS+=1
)

echo.
echo [3/3] 检测项目依赖...
if exist "%~dp0..\cli\node_modules" (
  echo   OK 依赖已安装
) else (
  echo   ! 依赖未安装，请运行: cd cli ^&^& npm install
)

echo.
echo ======================================

if %ERRORS% equ 0 (
  echo  环境检测通过
  echo ======================================
  exit /b 0
) else (
  echo  发现 %ERRORS% 个问题，请先安装 Node.js
  echo.
  echo  安装方式:
  echo    下载 https://nodejs.org 安装包
  echo ======================================
  exit /b 1
)
