#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(dirname "$SCRIPT_DIR")"

if [ -n "$1" ]; then
  OUTPUT_DIR="$1"
else
  OUTPUT_DIR="."
fi

# 版本号：时间戳
VERSION=$(date +"%Y%m%d%H%M")
SKILL_NAME="zentao"

echo "打包 $SKILL_NAME v$VERSION"
echo "   源目录: $SKILL_DIR"
echo "   输出目录: $OUTPUT_DIR"
echo ""

TMP_DIR=$(mktemp -d 2>/dev/null || echo "/tmp/zentao-pkg-$$")
trap "rm -rf '$TMP_DIR'" EXIT

echo "复制文件..."
mkdir -p "$TMP_DIR/$SKILL_NAME"
cp "$SKILL_DIR/SKILL.md" "$TMP_DIR/$SKILL_NAME/"
cp -r "$SKILL_DIR/references" "$TMP_DIR/$SKILL_NAME/"
cp -r "$SKILL_DIR/scripts" "$TMP_DIR/$SKILL_NAME/"
cp -r "$SKILL_DIR/cli" "$TMP_DIR/$SKILL_NAME/"

# 清理临时副本中的运行时文件（不删源文件）
rm -rf "$TMP_DIR/$SKILL_NAME/cli/node_modules"
rm -rf "$TMP_DIR/$SKILL_NAME/cli/.env"
rm -rf "$TMP_DIR/$SKILL_NAME/cli/package-lock.json"
rm -rf "$TMP_DIR/$SKILL_NAME/data"
find "$TMP_DIR" -name ".DS_Store" -delete 2>/dev/null || true
find "$TMP_DIR" -name "Thumbs.db" -delete 2>/dev/null || true

OUTPUT_FILE="$OUTPUT_DIR/${SKILL_NAME}-v${VERSION}.zip"
rm -f "$OUTPUT_FILE"

cd "$TMP_DIR"
if command -v zip >/dev/null 2>&1; then
  zip -r "$OUTPUT_FILE" "$SKILL_NAME" -x "*.DS_Store" -x "*Thumbs.db" -x "__MACOSX/*"
else
  echo "错误: 未找到 zip 命令，请安装 zip"
  exit 1
fi

echo ""
echo "打包完成: $OUTPUT_FILE"
echo "文件大小: $(ls -lh "$OUTPUT_FILE" 2>/dev/null | awk '{print $5}' || echo "unknown")"
