#!/bin/bash
# 环境检测脚本
# 用法: ./scripts/check-env.sh

echo "======================================"
echo " Zentao CLI 环境检测"
echo "======================================"
echo ""

ERRORS=0

# 检测 Node.js
echo "[1/3] 检测 Node.js..."
if command -v node >/dev/null 2>&1; then
  NODE_VERSION=$(node --version 2>/dev/null)
  NODE_MAJOR=$(echo "$NODE_VERSION" | cut -d'v' -f2 | cut -d'.' -f1)
  if [ "$NODE_MAJOR" -ge 18 ]; then
    echo "  ✅ Node.js $NODE_VERSION (满足 v18+ 要求)"
  else
    echo "  ❌ Node.js $NODE_VERSION (需要 v18 或更高)"
    ERRORS=$((ERRORS + 1))
  fi
else
  echo "  ❌ 未安装 Node.js"
  ERRORS=$((ERRORS + 1))
fi

# 检测 npm
echo ""
echo "[2/3] 检测 npm..."
if command -v npm >/dev/null 2>&1; then
  NPM_VERSION=$(npm --version 2>/dev/null)
  echo "  ✅ npm v$NPM_VERSION"
else
  echo "  ❌ 未安装 npm"
  ERRORS=$((ERRORS + 1))
fi

# 检测依赖是否安装
echo ""
echo "[3/3] 检测项目依赖..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLI_DIR="$(dirname "$SCRIPT_DIR")/cli"

if [ -d "$CLI_DIR/node_modules" ]; then
  echo "  ✅ 依赖已安装"
else
  echo "  ⚠️  依赖未安装，请运行: cd cli && npm install"
fi

echo ""
echo "======================================"

if [ $ERRORS -eq 0 ]; then
  echo " 环境检测通过"
  echo "======================================"
  exit 0
else
  echo " 发现 $ERRORS 个问题，请先安装 Node.js"
  echo ""
  echo " 安装方式："
  echo "   macOS:   brew install node"
  echo "   Linux:   apt install nodejs npm"
  echo "   Windows: 下载 https://nodejs.org"
  echo "======================================"
  exit 1
fi
