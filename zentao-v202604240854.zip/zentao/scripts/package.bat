@echo off
REM Zentao Skill 打包脚本 (Windows)
REM 用法: scripts\package.bat [输出目录]

setlocal enabledelayedexpansion

set SCRIPT_DIR=%~dp0
set SKILL_DIR=%SCRIPT_DIR%..

if not "%~1"=="" (
  set OUTPUT_DIR=%~1
) else (
  set OUTPUT_DIR=.
)

REM 版本号：时间戳
for /f "tokens=2 delims==" %%a in ('wmic os get localdatetime /value ^| findstr "="') do set DT=%%a
set VERSION=%DT:~0,12%

set SKILL_NAME=zentao

echo 打包 %SKILL_NAME% v%VERSION%
echo    源目录: %SKILL_DIR%
echo    输出目录: %OUTPUT_DIR%
echo.

set OUTPUT_FILE=%OUTPUT_DIR%\%SKILL_NAME%-v%VERSION%.zip
if exist "%OUTPUT_FILE%" del /q "%OUTPUT_FILE%"

REM 使用 PowerShell 打包
echo 复制并打包文件...
powershell -Command "Compress-Archive -Path '%SKILL_DIR%\SKILL.md','%SKILL_DIR%\cli','%SKILL_DIR%\scripts','%SKILL_DIR%\references' -DestinationPath '%OUTPUT_FILE%' -Force"

if exist "%OUTPUT_FILE%" (
  echo.
  echo 打包完成: %OUTPUT_FILE%
  for %%A in ("%OUTPUT_FILE%") do echo 文件大小: %%~zA 字节
) else (
  echo 错误: 打包失败
  exit /b 1
)
