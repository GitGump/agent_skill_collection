class PlansResource {
  constructor(client) {
    this.client = client;
  }

  async listByProduct(productId, params = {}) {
    return this.client.apiGet(`/products/${productId}/plans`, params);
  }

  async get(id) {
    return this.client.apiGet(`/plans/${id}`);
  }
}

module.exports = { PlansResource };
