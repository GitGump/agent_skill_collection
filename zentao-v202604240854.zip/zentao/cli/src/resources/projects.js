class ProjectsResource {
  constructor(client) {
    this.client = client;
  }

  async list(params = {}) {
    return this.client.getProjects(params);
  }

  async get(id) {
    return this.client.getProject(id);
  }

  async listExecutions(projectId, params = {}) {
    return this.client.request('GET', `/projects/${projectId}/executions`, null, { params });
  }

  async listStories(projectId, params = {}) {
    return this.client.request('GET', `/projects/${projectId}/stories`, null, { params });
  }

  async listBuilds(projectId, params = {}) {
    return this.client.request('GET', `/projects/${projectId}/builds`, null, { params });
  }
}

module.exports = { ProjectsResource };
