const { ZentaoClient } = require('../client');

class ProductsResource {
  constructor(client) {
    this.client = client;
  }

  async list(params = {}) {
    return this.client.getProducts(params);
  }

  async get(id) {
    return this.client.getProduct(id);
  }

  async listStories(productId, params = {}) {
    return this.client.request('GET', `/products/${productId}/stories`, null, { params });
  }

  async listBugs(productId, params = {}) {
    return this.client.request('GET', `/products/${productId}/bugs`, null, { params });
  }

  async listPlans(productId, params = {}) {
    return this.client.request('GET', `/products/${productId}/plans`, null, { params });
  }

  async listReleases(productId, params = {}) {
    return this.client.request('GET', `/products/${productId}/releases`, null, { params });
  }
}

module.exports = { ProductsResource };
