const { extractItems } = require('../utils');

class BugsResource {
  constructor(client) {
    this.client = client;
  }

  async listByProduct(productId, params = {}) {
    return this.client.request('GET', `/products/${productId}/bugs`, null, { params });
  }

  async list(params = {}) {
    return this.client.getBugs(params);
  }

  async get(id) {
    return this.client.getBug(id);
  }

  async countByStatus(params = {}) {
    const bugs = extractItems(await this.list(params));
    const result = { active: 0, resolved: 0, closed: 0, total: bugs.length };
    bugs.forEach(bug => {
      switch (bug.status) {
        case 'active':
        case 'confirmed':
          result.active++;
          break;
        case 'resolved':
          result.resolved++;
          break;
        case 'closed':
          result.closed++;
          break;
      }
    });
    return result;
  }

  async countBySeverity(params = {}) {
    const bugs = extractItems(await this.list(params));
    const result = {};
    bugs.forEach(bug => {
      const severity = bug.severity || 'unknown';
      result[severity] = (result[severity] || 0) + 1;
    });
    return result;
  }

  async countByModule(params = {}) {
    const bugs = extractItems(await this.list(params));
    const result = {};
    bugs.forEach(bug => {
      const mod = bug.moduleTitle || bug.module || 'unknown';
      result[mod] = (result[mod] || 0) + 1;
    });
    return result;
  }

  async countByAssignee(params = {}) {
    const bugs = extractItems(await this.list(params));
    const result = {};
    bugs.forEach(bug => {
      let assigneeName = 'unassigned';
      if (bug.assignedToRealName) {
        assigneeName = bug.assignedToRealName;
      } else if (bug.assignedTo) {
        if (typeof bug.assignedTo === 'object' && bug.assignedTo.realname) {
          assigneeName = bug.assignedTo.realname;
        } else if (typeof bug.assignedTo === 'string') {
          assigneeName = bug.assignedTo;
        }
      }
      result[assigneeName] = (result[assigneeName] || 0) + 1;
    });
    return result;
  }

  async getTrend(startDate, endDate, params = {}) {
    const bugs = extractItems(await this.list({ ...params, limit: 1000 }));
    const trend = {};
    bugs.forEach(bug => {
      const openedDate = bug.openedDate?.split(' ')[0];
      const resolvedDate = bug.resolvedDate?.split(' ')[0];
      if (openedDate && openedDate >= startDate && openedDate <= endDate) {
        trend[openedDate] = trend[openedDate] || { opened: 0, resolved: 0 };
        trend[openedDate].opened++;
      }
      if (resolvedDate && resolvedDate >= startDate && resolvedDate <= endDate) {
        trend[resolvedDate] = trend[resolvedDate] || { opened: 0, resolved: 0 };
        trend[resolvedDate].resolved++;
      }
    });
    return trend;
  }
}

module.exports = { BugsResource };
