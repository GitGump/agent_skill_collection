class VersionsResource {
  constructor(client) {
    this.client = client;
  }

  async listByProject(projectId, params = {}) {
    return this.client.request('GET', `/projects/${projectId}/builds`, null, { params });
  }

  async listByExecution(executionId, params = {}) {
    return this.client.request('GET', `/executions/${executionId}/builds`, null, { params });
  }

  async get(id) {
    return this.client.request('GET', `/builds/${id}`);
  }
}

module.exports = { VersionsResource };
