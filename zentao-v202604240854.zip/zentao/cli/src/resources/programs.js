class ProgramsResource {
  constructor(client) {
    this.client = client;
  }

  async list(params = {}) {
    return this.client.apiGet('/programs', params);
  }

  async get(id) {
    return this.client.apiGet(`/programs/${id}`);
  }
}

module.exports = { ProgramsResource };
