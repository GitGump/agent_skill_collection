class ReleasesResource {
  constructor(client) {
    this.client = client;
  }

  async listByProduct(productId, params = {}) {
    return this.client.apiGet(`/products/${productId}/releases`, params);
  }

  async listByProject(projectId, params = {}) {
    return this.client.apiGet(`/projects/${projectId}/releases`, params);
  }
}

module.exports = { ReleasesResource };
