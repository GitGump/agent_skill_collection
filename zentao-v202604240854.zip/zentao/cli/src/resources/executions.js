class ExecutionsResource {
  constructor(client) {
    this.client = client;
  }

  async listByProject(projectId, params = {}) {
    return this.client.request('GET', `/projects/${projectId}/executions`, null, { params });
  }

  async get(id) {
    return this.client.request('GET', `/executions/${id}`);
  }
}

module.exports = { ExecutionsResource };
