const { extractItems } = require('../utils');

class TasksResource {
  constructor(client) {
    this.client = client;
  }

  async listByExecution(executionId, params = {}) {
    return this.client.request('GET', `/executions/${executionId}/tasks`, null, { params });
  }

  async list(params = {}) {
    return this.client.getTasks(params);
  }

  async get(id) {
    return this.client.getTask(id);
  }

  async countByStatus(executionId) {
    const tasks = extractItems(await this.listByExecution(executionId));
    const result = {};
    tasks.forEach(t => {
      const status = t.status || 'unknown';
      result[status] = (result[status] || 0) + 1;
    });
    return result;
  }

  async countByAssignee(executionId) {
    const tasks = extractItems(await this.listByExecution(executionId));
    const result = {};
    tasks.forEach(t => {
      const assignee = t.assignedToRealName || t.assignedTo || 'unassigned';
      result[assignee] = (result[assignee] || 0) + 1;
    });
    return result;
  }

  async getProgress(executionId) {
    const tasks = extractItems(await this.listByExecution(executionId));
    const total = tasks.length;
    const done = tasks.filter(t => t.status === 'done' || t.status === 'closed').length;
    return {
      total,
      done,
      percent: total ? Math.round(done / total * 100) : 0,
    };
  }
}

module.exports = { TasksResource };
