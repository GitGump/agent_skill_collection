const { extractItems } = require('../utils');

class StoriesResource {
  constructor(client) {
    this.client = client;
  }

  async listByProduct(productId, params = {}) {
    return this.client.request('GET', `/products/${productId}/stories`, null, { params });
  }

  async listByProject(projectId, params = {}) {
    return this.client.request('GET', `/projects/${projectId}/stories`, null, { params });
  }

  async listByExecution(executionId, params = {}) {
    return this.client.request('GET', `/executions/${executionId}/stories`, null, { params });
  }

  async get(id) {
    return this.client.getStory(id);
  }

  async countByStatus(params = {}) {
    const stories = extractItems(await this.client.getStories(params));
    const result = {};
    stories.forEach(s => {
      const status = s.status || 'unknown';
      result[status] = (result[status] || 0) + 1;
    });
    return result;
  }

  async countByProduct(productId) {
    const stories = extractItems(await this.listByProduct(productId));
    const result = {};
    stories.forEach(s => {
      const status = s.status || 'unknown';
      result[status] = (result[status] || 0) + 1;
    });
    return result;
  }
}

module.exports = { StoriesResource };
