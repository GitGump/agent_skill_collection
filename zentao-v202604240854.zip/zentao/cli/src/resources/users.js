class UsersResource {
  constructor(client) {
    this.client = client;
  }

  async list(params = {}) {
    return this.client.apiGet('/users', params);
  }

  async get(id) {
    return this.client.apiGet(`/users/${id}`);
  }

  async me() {
    return this.client.apiGet('/user');
  }
}

module.exports = { UsersResource };
