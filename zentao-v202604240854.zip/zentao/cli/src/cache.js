const fs = require('fs');
const path = require('path');
const dayjs = require('dayjs');

// 默认缓存目录
const DEFAULT_CACHE_DIR = path.join(__dirname, '..', '..', 'data');

// 各类型的 TTL 配置（单位：小时）
const TTL_CONFIG = {
  products: 168,      // 7 天
  projects: 72,       // 3 天
  programs: 168,      // 7 天
  users: 168,         // 7 天
  executions: 24,     // 1 天（按项目分）
  relations: 72,      // 3 天
};

/**
 * 缓存管理器
 * 支持按类型分文件存储，TTL 过期自动失效
 */
class CacheManager {
  constructor(cacheDir) {
    this.cacheDir = cacheDir || DEFAULT_CACHE_DIR;
    this.metaPath = path.join(this.cacheDir, 'meta.json');
    this._meta = null;
  }

  // ========== 元数据管理 ==========

  _loadMeta() {
    if (this._meta) return this._meta;
    try {
      this._meta = JSON.parse(fs.readFileSync(this.metaPath, 'utf-8'));
    } catch {
      this._meta = {};
    }
    return this._meta;
  }

  _saveMeta() {
    fs.mkdirSync(this.cacheDir, { recursive: true });
    fs.writeFileSync(this.metaPath, JSON.stringify(this._loadMeta(), null, 2), 'utf-8');
  }

  _setMetaEntry(key, data) {
    const meta = this._loadMeta();
    meta[key] = {
      lastSync: dayjs().format('YYYY-MM-DD HH:mm:ss'),
      ttl: TTL_CONFIG[key.replace(/-\d+$/, '')] || 168,
      count: Array.isArray(data) ? data.length : Object.keys(data).length,
    };
    this._saveMeta();
  }

  // ========== 核心读写 ==========

  /**
   * 获取缓存文件路径
   * @param {string} type - 数据类型 (products, projects, users, executions-312, etc.)
   */
  _filePath(type) {
    // executions 按项目分文件：executions-312 → executions/312.json
    if (type.startsWith('executions-')) {
      const projectId = type.replace('executions-', '');
      const dir = path.join(this.cacheDir, 'executions');
      fs.mkdirSync(dir, { recursive: true });
      return path.join(dir, `${projectId}.json`);
    }
    return path.join(this.cacheDir, `${type}.json`);
  }

  /**
   * 检查缓存是否有效（存在且未过期）
   * @param {string} type - 数据类型
   * @returns {boolean}
   */
  isValid(type) {
    const meta = this._loadMeta();
    const entry = meta[type];
    if (!entry) return false;

    const ttlKey = type.startsWith('executions-') ? 'executions' : type;
    const ttlHours = TTL_CONFIG[ttlKey] || 168;
    const lastSync = dayjs(entry.lastSync);

    return dayjs().diff(lastSync, 'hour') < ttlHours;
  }

  /**
   * 读取缓存
   * @param {string} type - 数据类型
   * @returns {any|null} 缓存数据，过期或不存在返回 null
   */
  get(type) {
    if (!this.isValid(type)) return null;

    try {
      return JSON.parse(fs.readFileSync(this._filePath(type), 'utf-8'));
    } catch {
      return null;
    }
  }

  /**
   * 写入缓存
   * @param {string} type - 数据类型
   * @param {any} data - 缓存数据
   */
  set(type, data) {
    fs.mkdirSync(path.dirname(this._filePath(type)), { recursive: true });
    fs.writeFileSync(this._filePath(type), JSON.stringify(data, null, 2), 'utf-8');
    this._setMetaEntry(type, data);
  }

  /**
   * 读取缓存或调用 API 获取（带自动刷新）
   * @param {string} type - 数据类型
   * @param {Function} fetchFn - API 获取函数
   * @param {Object} options - 选项 { forceRefresh, silent }
   * @returns {Promise<any>}
   */
  async getOrFetch(type, fetchFn, options = {}) {
    if (!options.forceRefresh) {
      const cached = this.get(type);
      if (cached) {
        if (!options.silent) {
          process.stderr.write(`📦 使用缓存: ${type} (最后同步: ${this._loadMeta()[type]?.lastSync})\n`);
        }
        return cached;
      }
    }

    if (!options.silent) {
      process.stderr.write(`🌐 从 API 获取: ${type}...\n`);
    }
    const data = await fetchFn();
    this.set(type, data);
    return data;
  }

  // ========== 批量同步 ==========

  /**
   * 获取所有已缓存的类型列表
   */
  listCached() {
    const meta = this._loadMeta();
    return Object.entries(meta).map(([type, info]) => ({
      type,
      ...info,
      expired: !this.isValid(type),
    }));
  }

  /**
   * 清除所有缓存
   */
  clear() {
    if (fs.existsSync(this.cacheDir)) {
      const files = fs.readdirSync(this.cacheDir);
      for (const f of files) {
        const full = path.join(this.cacheDir, f);
        if (f === 'executions') {
          const sub = fs.readdirSync(full);
          for (const sf of sub) fs.unlinkSync(path.join(full, sf));
          fs.rmdirSync(full);
        } else if (f !== 'meta.json') {
          fs.unlinkSync(full);
        }
      }
    }
    this._meta = {};
    this._saveMeta();
  }
}

module.exports = { CacheManager, TTL_CONFIG, DEFAULT_CACHE_DIR };
