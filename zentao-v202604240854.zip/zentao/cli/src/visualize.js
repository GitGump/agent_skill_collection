const asciichart = require('asciichart');
const dayjs = require('dayjs');

/**
 * 数据可视化工具 - 使用 ASCII 图表
 */
class Visualizer {
  /**
   * 绘制柱状图
   * @param {Object} data - {label: value} 格式的数据
   * @param {string} title - 图表标题
   * @param {Object} options - 配置选项
   */
  bar(data, title = '', options = {}) {
    const entries = Object.entries(data);
    if (entries.length === 0) return '暂无数据';

    const maxLabelLen = Math.max(...entries.map(([k]) => k.length));
    const maxValue = Math.max(...entries.map(([, v]) => Number(v) || 0));
    const width = options.width || 40;

    const lines = title ? [`\n${title}`, '─'.repeat(title.length + 2)] : [];

    entries.forEach(([label, value]) => {
      const numVal = Number(value) || 0;
      const barLen = maxValue > 0 ? Math.round((numVal / maxValue) * width) : 0;
      const bar = '█'.repeat(barLen);
      const paddedLabel = label.padEnd(maxLabelLen);
      lines.push(`${paddedLabel} │${bar} ${numVal}`);
    });

    return lines.join('\n');
  }

  /**
   * 绘制饼图（使用 ASCII 字符）
   * @param {Object} data - {label: value} 格式的数据
   * @param {string} title - 图表标题
   */
  pie(data, title = '') {
    const entries = Object.entries(data);
    if (entries.length === 0) return '暂无数据';

    const total = entries.reduce((sum, [, v]) => sum + (Number(v) || 0), 0);
    if (total === 0) return '暂无数据';

    const colors = ['🔴', '🟢', '🔵', '🟡', '🟣', '🟠', '⚪', '🟤'];
    const lines = title ? [`\n${title}`] : [];

    entries.forEach(([label, value], i) => {
      const percent = ((Number(value) || 0) / total * 100).toFixed(1);
      const color = colors[i % colors.length];
      lines.push(`${color} ${label.padEnd(15)} ${String(value).padStart(4)} (${percent}%)`);
    });

    lines.push(`   总计: ${total}`);
    return lines.join('\n');
  }

  /**
   * 绘制趋势折线图
   * @param {Object} data - {date: {opened, resolved}} 格式的数据
   * @param {string} title - 图表标题
   * @param {string} startDate - 开始日期
   * @param {string} endDate - 结束日期
   */
  trend(data, title = 'BUG 趋势', startDate, endDate) {
    const dates = Object.keys(data).sort();
    if (dates.length === 0) return '暂无数据';

    const opened = dates.map(d => data[d].opened || 0);
    const resolved = dates.map(d => data[d].resolved || 0);

    // 使用 asciichart 绘制
    const config = {
      height: 10,
      padding: '    ',
      colors: [
        asciichart.red,
        asciichart.green,
      ],
    };

    const lines = [`\n${title}`, ''];
    lines.push(asciichart.plot([opened, resolved], config));
    lines.push('');
    lines.push('🔴 新增    🟢 解决');

    return lines.join('\n');
  }

  /**
   * 绘制累计流图（CFD）
   * @param {Array} data - 按日期排序的状态数据 [{date, todo, doing, done}]
   * @param {string} title - 图表标题
   */
  cfd(data, title = '累计流图') {
    if (data.length === 0) return '暂无数据';

    const dates = data.map(d => d.date.slice(5)); // 只显示 MM-DD
    const todo = data.map(d => d.todo || 0);
    const doing = data.map(d => d.doing || 0);
    const done = data.map(d => d.done || 0);

    const config = {
      height: 12,
      padding: '    ',
      colors: [
        asciichart.lightcyan,
        asciichart.yellow,
        asciichart.green,
      ],
    };

    const lines = [`\n${title}`, ''];
    lines.push(asciichart.plot([todo, doing, done], config));
    lines.push('');
    lines.push('⚪ 待办    🟡 进行中    🟢 已完成');

    return lines.join('\n');
  }

  /**
   * 绘制燃尽图
   * @param {Array} data - 燃尽数据 [{date, ideal, actual}]
   * @param {string} title - 图表标题
   */
  burndown(data, title = '燃尽图') {
    if (data.length === 0) return '暂无数据';

    const ideal = data.map(d => d.ideal || 0);
    const actual = data.map(d => d.actual || 0);

    const config = {
      height: 12,
      padding: '    ',
      colors: [
        asciichart.lightcyan, // 理想线
        asciichart.red,       // 实际线
      ],
    };

    const lines = [`\n${title}`, ''];
    lines.push(asciichart.plot([ideal, actual], config));
    lines.push('');
    lines.push('⚪ 理想    🔴 实际');

    return lines.join('\n');
  }

  /**
   * 生成进度条
   * @param {number} percent - 百分比 (0-100)
   * @param {number} width - 宽度
   */
  progress(percent, width = 30) {
    const filled = Math.round((percent / 100) * width);
    const empty = width - filled;
    const bar = '█'.repeat(filled) + '░'.repeat(empty);
    return `[${bar}] ${percent.toFixed(1)}%`;
  }

  /**
   * 生成统计摘要卡片
   * @param {Object} stats - 统计数据
   */
  summaryCard(stats) {
    const lines = ['\n┌' + '─'.repeat(48) + '┐'];

    Object.entries(stats).forEach(([label, value]) => {
      const line = `│ ${label.padEnd(20)}: ${String(value).padEnd(24)}│`;
      lines.push(line);
    });

    lines.push('└' + '─'.repeat(48) + '┘');
    return lines.join('\n');
  }
}

module.exports = { Visualizer };
