const axios = require('axios');
require('dotenv').config();

/**
 * 禅道 API 客户端
 * 
 * 支持三种认证方式（优先级从高到低）：
 * 
 * 1. REST API Token（推荐）：账号密码换取 Token，自动维护
 *    - 获取方法：执行 `zentao login` 命令
 *    - 或直接调用 POST /api.php/v1/tokens
 * 
 * 2. Cookie 方式：za + zp 长期登录凭证
 *    - 获取方法：浏览器登录后，从 Cookie 中提取 za 和 zp
 * 
 * 3. Session 方式：zentaosid 临时会话
 *    - 获取方法：调用 /api-getsessionid.json + /user-login.json
 * 
 * REST API 文档：http://10.240.1.200/dev-api-restapi.html
 */
class ZentaoClient {
  constructor(baseURL, options = {}) {
    this.baseURL = baseURL || process.env.ZENTAO_URL || 'http://10.240.1.200';
    this.apiBase = `${this.baseURL}/api.php/v1`;
    
    // REST API Token 认证（推荐）
    this.token = options.token || process.env.ZENTAO_TOKEN;
    this.account = options.account || process.env.ZENTAO_ACCOUNT;
    this.password = options.password || process.env.ZENTAO_PASSWORD;
    
    // Cookie 认证
    this.za = options.za || process.env.ZENTAO_ZA;
    this.zp = options.zp || process.env.ZENTAO_ZP;
    
    // Session 认证
    this.sessionId = options.sessionId || process.env.ZENTAO_SESSION_ID;

    // 创建两个客户端：一个用于 HTML 页面，一个用于 REST API
    this.client = axios.create({ baseURL: this.baseURL, timeout: 30000 });
    this.apiClient = axios.create({ baseURL: this.apiBase, timeout: 30000 });

    // HTML 客户端拦截器：添加 Cookie 认证
    this.client.interceptors.request.use(
      (config) => {
        const cookies = [];
        if (this.za && this.zp) {
          cookies.push(`za=${this.za}`, `zp=${this.zp}`, 'keepLogin=on');
        }
        if (this.sessionId) {
          cookies.push(`zentaosid=${this.sessionId}`);
        }
        cookies.push('lang=zh-cn', 'vision=rnd', 'device=desktop', 'theme=default');
        if (cookies.length > 0) config.headers['Cookie'] = cookies.join('; ');
        return config;
      },
      (error) => Promise.reject(error)
    );

    // REST API 客户端拦截器：添加 Token 认证
    this.apiClient.interceptors.request.use(
      (config) => {
        if (this.token) {
          config.headers['Token'] = this.token;
        }
        return config;
      },
      (error) => Promise.reject(error)
    );

    // 响应拦截器
    [this.client, this.apiClient].forEach(c => {
      c.interceptors.response.use(
        (response) => response.data,
        (error) => {
          const message = error.response?.data?.error || error.message;
          return Promise.reject(new Error(`API Error: ${message}`));
        }
      );
    });
  }

  // ========== 认证方法 ==========
  
  /**
   * 用账号密码换取 Token（推荐）
   * @returns {Promise<string>} token
   */
  async login() {
    if (!this.account || !this.password) {
      throw new Error('请设置 ZENTAO_ACCOUNT 和 ZENTAO_PASSWORD');
    }
    const resp = await this.apiClient.post('/tokens', {
      account: this.account,
      password: this.password
    });
    this.token = resp.token;
    return this.token;
  }

  /**
   * 用账号密码换取 Session（备用方案）
   * @returns {Promise<string>} sessionId
   */
  async loginWithSession() {
    // 获取 session ID
    const sessionResp = await this.client.get('/api-getsessionid.json');
    const sessionData = typeof sessionResp.data === 'string' 
      ? JSON.parse(sessionResp.data) 
      : sessionResp.data;
    this.sessionId = sessionData.sessionID;
    
    // 登录
    const params = new URLSearchParams();
    params.append('account', this.account);
    params.append('password', this.password);
    params.append('zentaosid', this.sessionId);
    await this.client.post('/user-login.json', params);
    
    return this.sessionId;
  }

  setCredentials(za, zp) { this.za = za; this.zp = zp; }
  setSession(sessionId) { this.sessionId = sessionId; }
  setToken(token) { this.token = token; }

  // ========== REST API 方法 ==========
  async apiGet(path, params = {}) { return this.apiClient.get(path, { params }); }
  async apiPost(path, data = {}) { return this.apiClient.post(path, data); }
  async apiPut(path, data = {}) { return this.apiClient.put(path, data); }
  async apiDelete(path) { return this.apiClient.delete(path); }

  // ========== 产品 ==========
  async getProducts(params = {}) {
    if (this.token) return this.apiGet('/products', params);
    return this.client.get('/product-all.html', { params });
  }

  async getProduct(id) {
    if (this.token) return this.apiGet(`/products/${id}`);
    return this.client.get(`/product-view-${id}.html`);
  }

  // ========== 项目 ==========
  async getProjects(params = {}) {
    if (this.token) return this.apiGet('/projects', params);
    return this.client.get('/project-browse.html', { params });
  }

  async getProject(id) {
    if (this.token) return this.apiGet(`/projects/${id}`);
    return this.client.get(`/project-index-${id}.html`);
  }

  // ========== 执行/迭代 ==========
  async getExecutions(projectId, params = {}) {
    if (this.token) return this.apiGet(`/projects/${projectId}/executions`, params);
    return this.client.get(`/execution-all-${projectId}.html`, { params });
  }

  async getExecution(id) {
    if (this.token) return this.apiGet(`/executions/${id}`);
    return this.client.get(`/execution-task-${id}.html`);
  }

  // ========== 需求 ==========
  async getStories(params = {}) {
    if (this.token) return this.apiGet('/stories', params);
    return this.client.get('/story-browse.html', { params });
  }

  async getStory(id) {
    if (this.token) return this.apiGet(`/stories/${id}`);
    return this.client.get(`/story-view-${id}.html`);
  }

  // ========== 任务 ==========
  async getTasks(params = {}) {
    if (this.token) return this.apiGet('/tasks', params);
    return this.client.get('/task-browse.html', { params });
  }

  async getTask(id) {
    if (this.token) return this.apiGet(`/tasks/${id}`);
    return this.client.get(`/task-view-${id}.html`);
  }

  // ========== BUG ==========
  async getBugs(params = {}) {
    if (this.token) return this.apiGet('/bugs', params);
    return this.client.get('/bug-browse.html', { params });
  }

  async getBug(id) {
    if (this.token) return this.apiGet(`/bugs/${id}`);
    return this.client.get(`/bug-view-${id}.html`);
  }

  // ========== 版本 ==========
  async getVersions(projectId, params = {}) {
    if (this.token) return this.apiGet(`/projects/${projectId}/builds`, params);
    return this.client.get(`/project-build-${projectId}.html`, { params });
  }

  async getVersion(id) {
    if (this.token) return this.apiGet(`/builds/${id}`);
    return this.client.get(`/build-view-${id}.html`);
  }

  // ========== 用户 ==========
  async getUsers(params = {}) {
    if (this.token) return this.apiGet('/users', params);
    return this.client.get('/user-browse.html', { params });
  }

  async getUser(id) {
    if (this.token) return this.apiGet(`/users/${id}`);
    return this.client.get(`/user-view-${id}.html`);
  }

  // ========== 通用请求 ==========
  async request(method, path, data, config = {}) {
    const client = this.token ? this.apiClient : this.client;
    return client.request({
      method,
      url: path,
      data,
      ...config,
    });
  }
}

module.exports = { ZentaoClient };
