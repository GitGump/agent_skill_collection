const ExcelJS = require('exceljs');
const fs = require('fs');
const path = require('path');

/**
 * 数据导出工具
 */
class Exporter {
  /**
   * 导出为 Excel
   * @param {Array} data - 数据数组
   * @param {Array} columns - 列定义 [{key, label, width}]
   * @param {string} filename - 文件名
   * @param {string} sheetName - 工作表名称
   */
  async toExcel(data, columns, filename, sheetName = 'Sheet1') {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet(sheetName);

    // 设置列
    worksheet.columns = columns.map(col => ({
      header: col.label,
      key: col.key,
      width: col.width || 15,
    }));

    // 添加数据
    data.forEach(row => {
      const rowData = {};
      columns.forEach(col => {
        rowData[col.key] = getNestedValue(row, col.key);
      });
      worksheet.addRow(rowData);
    });

    // 样式：表头加粗
    worksheet.getRow(1).font = { bold: true };
    worksheet.getRow(1).fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFE0E0E0' },
    };

    // 确保目录存在
    const dir = path.dirname(filename);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    await workbook.xlsx.writeFile(filename);
    return filename;
  }

  /**
   * 导出为 CSV
   * @param {Array} data - 数据数组
   * @param {Array} columns - 列定义
   * @param {string} filename - 文件名
   */
  async toCSV(data, columns, filename) {
    const lines = [];

    // 表头
    lines.push(columns.map(col => `"${col.label}"`).join(','));

    // 数据行
    data.forEach(row => {
      const values = columns.map(col => {
        const val = getNestedValue(row, col.key);
        if (val === null || val === undefined) return '""';
        const str = String(val).replace(/"/g, '""');
        return `"${str}"`;
      });
      lines.push(values.join(','));
    });

    // 确保目录存在
    const dir = path.dirname(filename);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    fs.writeFileSync(filename, lines.join('\n'), 'utf-8');
    return filename;
  }

  /**
   * 导出为 JSON
   * @param {Array|Object} data - 数据
   * @param {string} filename - 文件名
   */
  async toJSON(data, filename) {
    const dir = path.dirname(filename);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    fs.writeFileSync(filename, JSON.stringify(data, null, 2), 'utf-8');
    return filename;
  }
}

/**
 * 获取嵌套对象值
 */
function getNestedValue(obj, path) {
  return path.split('.').reduce((o, k) => o?.[k], obj);
}

module.exports = { Exporter };
