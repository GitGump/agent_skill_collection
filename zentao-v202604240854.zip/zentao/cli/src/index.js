const { ZentaoClient } = require('./client');
const { ProductsResource } = require('./resources/products');
const { ProjectsResource } = require('./resources/projects');
const { ExecutionsResource } = require('./resources/executions');
const { StoriesResource } = require('./resources/stories');
const { TasksResource } = require('./resources/tasks');
const { BugsResource } = require('./resources/bugs');
const { VersionsResource } = require('./resources/versions');
const { ProgramsResource } = require('./resources/programs');
const { PlansResource } = require('./resources/plans');
const { ReleasesResource } = require('./resources/releases');
const { UsersResource } = require('./resources/users');

/**
 * 禅道 SDK 主入口
 */
class ZentaoSDK {
  constructor(options = {}) {
    const baseURL = options.baseURL || process.env.ZENTAO_URL || 'http://10.240.1.200';
    const token = options.token || process.env.ZENTAO_TOKEN;

    this.client = new ZentaoClient(baseURL, token);
    this.products = new ProductsResource(this.client);
    this.projects = new ProjectsResource(this.client);
    this.executions = new ExecutionsResource(this.client);
    this.stories = new StoriesResource(this.client);
    this.tasks = new TasksResource(this.client);
    this.bugs = new BugsResource(this.client);
    this.versions = new VersionsResource(this.client);
    this.programs = new ProgramsResource(this.client);
    this.plans = new PlansResource(this.client);
    this.releases = new ReleasesResource(this.client);
    this.users = new UsersResource(this.client);
  }

  /**
   * 设置 Token
   */
  setToken(token) {
    this.client.setToken(token);
  }

  /**
   * 获取 Token（通过账号密码）
   */
  async getToken(account, password) {
    const axios = require('axios');
    const baseURL = this.client.baseURL || process.env.ZENTAO_URL || 'http://10.240.1.200';
    const resp = await axios.post(`${baseURL}/api.php/v1/tokens`, { account, password });
    const result = resp.data;
    if (result.token) {
      this.client.setToken(result.token);
    }
    return result;
  }

  /**
   * 获取当前登录用户信息
   */
  async getProfile() {
    return this.client.apiGet('/user');
  }
}

module.exports = { ZentaoSDK, ZentaoClient };
