const dayjs = require('dayjs');

/**
 * 格式化日期时间
 * @param {string|number} time - 时间戳或日期字符串
 * @param {string} format - 输出格式
 * @returns {string}
 */
function formatDate(time, format = 'YYYY-MM-DD HH:mm:ss') {
  if (!time) return '-';
  return dayjs(time).format(format);
}

/**
 * 格式化数据为表格
 * @param {Array} data - 数据数组
 * @param {Array} columns - 列定义 [{key, label, width, format}]
 * @returns {string}
 */
function formatTable(data, columns) {
  if (!data || data.length === 0) {
    return '暂无数据';
  }

  // 计算每列宽度
  const colWidths = columns.map(col => {
    const headerLen = col.label.length;
    const maxDataLen = Math.max(...data.map(row => {
      const val = getNestedValue(row, col.key);
      return String(val || '').length;
    }));
    return Math.max(headerLen, maxDataLen, col.width || 0) + 2;
  });

  // 分隔线
  const separator = '+' + colWidths.map(w => '-'.repeat(w)).join('+') + '+';

  // 表头
  const header = '|' + columns.map((col, i) => {
    return ' ' + col.label.padEnd(colWidths[i] - 1);
  }).join('|') + '|';

  // 数据行
  const rows = data.map(row => {
    return '|' + columns.map((col, i) => {
      const val = getNestedValue(row, col.key);
      const formatted = col.format ? col.format(val, row) : String(val || '-');
      return ' ' + formatted.padEnd(colWidths[i] - 1);
    }).join('|') + '|';
  });

  return [separator, header, separator, ...rows, separator].join('\n');
}

/**
 * 获取嵌套对象值
 * @param {Object} obj - 对象
 * @param {string} path - 路径，如 'user.name'
 * @returns {any}
 */
function getNestedValue(obj, path) {
  return path.split('.').reduce((o, k) => o?.[k], obj);
}

/**
 * 过滤对象
 * @param {Object} obj - 对象
 * @param {Function} predicate - 过滤函数
 * @returns {Object}
 */
function filterObject(obj, predicate) {
  return Object.fromEntries(
    Object.entries(obj).filter(([k, v]) => predicate(k, v))
  );
}

/**
 * 分页参数处理
 * @param {Object} params - 参数对象
 * @param {number} page - 页码
 * @param {number} limit - 每页数量
 * @returns {Object}
 */
function withPagination(params, page = 1, limit = 100) {
  return {
    ...params,
    page,
    limit,
  };
}

/**
 * 延迟函数
 * @param {number} ms - 毫秒
 * @returns {Promise}
 */
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * 从 REST API 分页响应中提取数据数组
 * REST API 返回格式: { page, total, limit, <resource>: [...] }
 * @param {any} data - API 响应数据
 * @returns {Array}
 */
function extractItems(data) {
  if (Array.isArray(data)) return data;
  if (data && typeof data === 'object') {
    for (const key of Object.keys(data)) {
      if (Array.isArray(data[key])) return data[key];
    }
  }
  return [data];
}

module.exports = {
  formatDate,
  formatTable,
  getNestedValue,
  filterObject,
  withPagination,
  sleep,
  extractItems,
};
